/* hangman_gtk3.c
 *
 * Compile:
 *   gcc hangman.c -o hangman `pkg-config --cflags --libs gtk+-3.0`
 */

#include <gtk/gtk.h>
#include <cairo.h>		//For the HANGMAN structure
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>

#define MAX_WORDS 10000
#define MAX_WORD_LEN 128
#define MAX_WRONG 6
#define WORDS_FILE "words.txt"
#define SCORE_FILE "score.txt"

static char *words[MAX_WORDS];
static int word_count=0;
static char secret[MAX_WORD_LEN];
static char display_word[MAX_WORD_LEN*2]; /*spaced representation*/
static char wrong_letters[128];
static int wrong_count=0;
static int wins=0;
static int losses=0;
static int countdown=5;


static GtkWidget *label_word;
static GtkWidget *label_wrong;
static GtkWidget *drawing_area;
static GtkWidget *btn_grid;
static GtkWidget *score_label;
static GtkWidget *difficulty_combo;
static guint turn_timer_id = 0;
static int time_left = 5;
static GtkWidget *label_timer;
static GtkWidget *window;
static gboolean is_dark_mode = FALSE;  
static GtkCssProvider *css_provider = NULL;
static GtkCssProvider *p = NULL;  

static void reset_game(void);
static void save_score(void);

static void free_words(void) {
    for (int i=0; i<word_count; ++i) {
        g_free(words[i]);
        words[i] = NULL;
    }
    word_count=0;
}

static void load_words_from_file(const char *path) {
    free_words();
    FILE *f = fopen(path, "r");
    if (!f){
        g_warning("Could not open %s falling back to builtin list", path);
        const char *builtin[] = {
            "APPLE", "BANANA", "HANGMAN", "PROGRAM", "COMPUTER", "ORANGE", "WELCOME",
            "BUTTON", "WINDOW", "KEYBOARD", "GITHUB", "LIBRARY", "NETWORK", "GRAPHICS",
            "MOUNTAIN", "RIVER", "SUNSHINE", "PYTHON", "HARDWARE"
        };
        int n = sizeof(builtin)/sizeof(builtin[0]);
        for (int i=0; i<n && i<MAX_WORDS; ++i) {
            words[word_count++] = g_strdup(builtin[i]);
        }
        return;
    }

    char line[MAX_WORD_LEN];
    while (fgets(line, sizeof(line), f) && word_count < MAX_WORDS) {
        char *p = line;
        while (*p && isspace((unsigned char)*p)) ++p;
        char *q = p+strlen(p)-1;
        while (q>=p && isspace((unsigned char)*q)) {*q='\0'; --q; }
        if (strlen(p)>=1) {
            for (char *r = p; *r; ++r) *r = toupper((unsigned char)*r);
            words[word_count++] = g_strdup(p);
        }
    }
    fclose(f);
}

static void save_score(void) {
    FILE *f = fopen(SCORE_FILE, "w");
    if (!f) return;
    fprintf(f, "%d %d\n", wins, losses);
    fclose(f);
}

static void load_score(void) {
    FILE *f = fopen(SCORE_FILE, "r");
    if (!f) return;
    if (fscanf(f, "%d %d", &wins, &losses) != 2) {
        wins = 0;
        losses = 0;
    }
    fclose(f);
}

static void update_score_label(void) {
    char buf[128];
    snprintf(buf, sizeof(buf), "Wins: %d    Losses: %d", wins, losses);
    gtk_label_set_text(GTK_LABEL(score_label), buf);
}

/* ---------- CSS (dark/light) ---------- */
static void apply_css_for_mode(void) {
    GtkStyleContext *ctx = gtk_widget_get_style_context(GTK_WIDGET(window));
    if (is_dark_mode) {
        gtk_style_context_add_class(ctx, "dark-mode");
        gtk_style_context_remove_class(ctx, "light-mode");
    } else {
        gtk_style_context_add_class(ctx, "light-mode");
        gtk_style_context_remove_class(ctx, "dark-mode");
    }
    gtk_widget_queue_draw(window);
}

static void ensure_css_provider(void)
{
    if (p) return;

    p = gtk_css_provider_new();
    gtk_css_provider_load_from_data(p,
        "window { background: #222; color: #eee; }",
        -1, NULL);

    GdkScreen *screen = gdk_screen_get_default();
    gtk_style_context_add_provider_for_screen(
        screen,
        GTK_STYLE_PROVIDER(p),
        GTK_STYLE_PROVIDER_PRIORITY_USER
    );
}


static void toggle_dark_mode(GtkWidget *w, gpointer user_data) {
    (void)w; (void)user_data;
    is_dark_mode = !is_dark_mode;
    apply_css_for_mode();
}

static const gchar *get_selected_difficulty(void) {
    if (!GTK_IS_COMBO_BOX_TEXT(difficulty_combo)) return NULL;
    return gtk_combo_box_text_get_active_text(GTK_COMBO_BOX_TEXT(difficulty_combo));
}

static void pick_random_word_for_difficulty(void) {
    const char *difficulty = get_selected_difficulty();
    int tries = 0;
    int idx = -1;
    if (word_count == 0) {
        strncpy(secret, "HANGMAN", MAX_WORD_LEN - 1);
        secret[MAX_WORD_LEN - 1] = '\0';
        return;
    }
    while (tries < 500) {
        int r = rand() % word_count;
        const char *w = words[r];
        int L = strlen(w);
        int accept = 0;

        /* difficulty: default = Medium */
        if (!difficulty) { 
            if (L>=5 && L<=7) accept = 1;
        } else if (strcmp(difficulty, "Easy")==0) {
            if (L>=8) accept = 1;
        } else if (strcmp(difficulty, "Medium")==0) {
            if (L>=5 && L<=7) accept = 1;
        } else if (strcmp(difficulty, "Hard")==0) {
            if (L<=5) accept = 1;
        } else {
            accept=1;
        }

        if (accept) { idx=r; break; }
        tries++;
    }
    if (idx==-1) idx = rand()%word_count;
    strncpy(secret, words[idx], MAX_WORD_LEN-1);
    secret[MAX_WORD_LEN-1] = '\0';
}

/* Prepare a spaced display_word from secret with '_' for letters and '-' preserved */
static void build_display_word(void) {
    size_t L = strlen(secret);
    char tmp[MAX_WORD_LEN*2];
    tmp[0] = '\0';
    for (size_t i=0; i<L; ++i) {
        char ch = secret[i];
        if (ch== '-' || ch== ' ') {
            strncat(tmp, (ch== ' ') ? "  " : "- ", sizeof(tmp)-strlen(tmp)-1);
        } else {
            strncat(tmp, "_ ", sizeof(tmp)-strlen(tmp)-1);
        }
    }
    tmp[sizeof(tmp)-1] = '\0';
    strncpy(display_word, tmp, sizeof(display_word)-1);
    display_word[sizeof(display_word)-1] = '\0';
}

/* Update labels for word and wrong letters */
static void update_display_label(void) {
    gtk_label_set_text(GTK_LABEL(label_word), display_word);
    gtk_label_set_text(GTK_LABEL(label_wrong), wrong_letters);
}

/* Disable/Enable letter buttons helpers */
static void disable_all_letter_buttons(void) {
    if (!GTK_IS_WIDGET(btn_grid)) return;
    GList *children = gtk_container_get_children(GTK_CONTAINER(btn_grid));
    for (GList *l = children; l; l = l->next) {
        GtkWidget *w = GTK_WIDGET(l->data);
        if (GTK_IS_BUTTON(w)) gtk_widget_set_sensitive(w, FALSE);
    }
    g_list_free(children);
}

static void enable_all_letter_buttons(void) {
    if (!GTK_IS_WIDGET(btn_grid)) return;
    GList *children = gtk_container_get_children(GTK_CONTAINER(btn_grid));
    for (GList *l = children; l; l = l->next) {
        GtkWidget *w = GTK_WIDGET(l->data);
        if (GTK_IS_BUTTON(w)) gtk_widget_set_sensitive(w, TRUE);
    }
    g_list_free(children);
}

/* Fill display_word with revealed letters according to secret and guessed letters */
static void reveal_letters_from_guess(char guessed) {
    size_t L = strlen(secret);
    char new_disp[MAX_WORD_LEN * 2];
    new_disp[0] = '\0';

    gboolean revealed[256] = { FALSE };
    for (size_t i = 0; i < strlen(display_word); ++i) {
        char c = display_word[i];
        if (c >= 'A' && c <= 'Z') revealed[(unsigned char)c] = TRUE;
    }

    if (guessed >= 'A' && guessed <= 'Z') revealed[(unsigned char)guessed] = TRUE;

    for (size_t i = 0; i < L; ++i) {
        char s = secret[i];
        if (s == '-' || s == ' ') {
            strncat(new_disp, (s == ' ') ? "  " : "- ", sizeof(new_disp) - strlen(new_disp) - 1);
        } else if (revealed[(unsigned char)s]) {
            char buf[4] = { s, ' ', 0 };
            strncat(new_disp, buf, sizeof(new_disp) - strlen(new_disp) - 1);
        } else {
            strncat(new_disp, "_ ", sizeof(new_disp) - strlen(new_disp) - 1);
        }
    }
    strncpy(display_word, new_disp, sizeof(display_word) - 1);
    display_word[sizeof(display_word) - 1] = '\0';
}

/* Helper: check if player has completely revealed the word */
static gboolean is_word_revealed(void) {
    return (strchr(display_word, '_') == NULL);
}

/* ---------- Timer ---------- */

static gboolean timer_tick(gpointer data) {
    (void)data;
    time_left--;
    char buf[64];
    snprintf(buf, sizeof(buf), "Time: %d", time_left);
    gtk_label_set_text(GTK_LABEL(label_timer), buf);

    if (time_left <= 0) {
        /* count as wrong guess */
        wrong_count++;
        /* add a '*' to wrong_letters to indicate timeout */
        size_t len = strlen(wrong_letters);
        if (len < sizeof(wrong_letters) - 3) {
            wrong_letters[len] = '*';
            wrong_letters[len+1] = ' ';
            wrong_letters[len+2] = '\0';
        }
        gtk_widget_queue_draw(drawing_area);
        update_display_label();

        if (wrong_count >= MAX_WRONG) {
            turn_timer_id = 0;
            g_idle_add((GSourceFunc)gtk_widget_queue_draw, drawing_area);
            return G_SOURCE_REMOVE;
        }

        /* reset time for next guess */
        time_left = 5;
        snprintf(buf, sizeof(buf), "Time: %d", time_left);
        gtk_label_set_text(GTK_LABEL(label_timer), buf);
    }
    return G_SOURCE_CONTINUE;
}

static void start_turn_timer(void) {
    if (turn_timer_id != 0) {
        g_source_remove(turn_timer_id);
        turn_timer_id = 0;
    }
    time_left = 5;
    gtk_label_set_text(GTK_LABEL(label_timer), "Time: 5");
    /* Use 1-second interval */
    turn_timer_id = g_timeout_add_seconds(1, timer_tick, NULL);
}

static void stop_turn_timer(void) {
    if (turn_timer_id != 0) {
        g_source_remove(turn_timer_id);
        turn_timer_id = 0;
    }
}

static gboolean countdown_tick(gpointer data) {
    char buf[64];
    snprintf(buf, sizeof(buf), "Game starts in... %d", countdown);
    gtk_label_set_text(GTK_LABEL(label_timer), buf);

    if (--countdown <= 0) {
        countdown = 3; // reset for next time
        reset_game();
        return G_SOURCE_REMOVE;
    }
    return G_SOURCE_CONTINUE;
}


/* ---------- Game outcome handling ---------- */

static void ask_play_again_and_reset(const char *title, const char *message, gboolean won) {
    stop_turn_timer();
    GtkWidget *dialog = gtk_message_dialog_new(GTK_WINDOW(window),
                                               GTK_DIALOG_MODAL,
                                               GTK_MESSAGE_INFO,
                                               GTK_BUTTONS_NONE,
                                               "%s", message);
    gtk_window_set_title(GTK_WINDOW(dialog), title);
    gtk_dialog_add_buttons(GTK_DIALOG(dialog),
                           "_Play Again", GTK_RESPONSE_OK,
                           "_Quit", GTK_RESPONSE_CANCEL,
                           NULL);
    gint resp = gtk_dialog_run(GTK_DIALOG(dialog));
    gtk_widget_destroy(dialog);

    if (resp == GTK_RESPONSE_OK) {
        /* start new game */
        reset_game();
    } else {
        /* save score and quit */
        save_score();
        gtk_main_quit();
    }
}

static void handle_win(void) {
    stop_turn_timer();
    wins++;
    save_score();
    update_score_label();

    char buf[256];
    snprintf(buf, sizeof(buf), "You Win!\nThe word was: %s", secret);
    ask_play_again_and_reset("Victory!", buf, TRUE);
}

static void handle_loss(void) {
    stop_turn_timer();
    losses++;
    save_score();
    update_score_label();

    char buf[256];
    snprintf(buf, sizeof(buf), "You Lose!\nThe word was: %s", secret);
    ask_play_again_and_reset("Game Over", buf, FALSE);
}

/* ---------- Drawing hangman ---------- */
static gboolean on_draw(GtkWidget *widget, cairo_t *cr, gpointer user_data) {
    (void)user_data;

    int w = gtk_widget_get_allocated_width(widget);
    int h = gtk_widget_get_allocated_height(widget);

    int base_x = w / 4;      // starting x for hangman
    int base_y = h - 50;     // ground y

    /* Background */
    if (is_dark_mode)
        cairo_set_source_rgb(cr, 0.08, 0.08, 0.08);
    else
        cairo_set_source_rgb(cr, 1.0, 1.0, 1.0);
    cairo_paint(cr);

    /* Drawing color */
    if (is_dark_mode) cairo_set_source_rgb(cr, 1, 1, 1);
    else cairo_set_source_rgb(cr, 0, 0, 0);
    cairo_set_line_width(cr, 4.0);

    /* ---------- Hangman Structure ---------- */
    if (wrong_count >= 1) {
        // Ground
        cairo_move_to(cr, base_x - 50, base_y);
        cairo_line_to(cr, base_x + 50, base_y);
        cairo_stroke(cr);
    }
    if (wrong_count >= 2) {
        // Vertical pole
        cairo_move_to(cr, base_x, base_y);
        cairo_line_to(cr, base_x, base_y - 150);
        cairo_stroke(cr);
    }
    if (wrong_count >= 3) {
        // Horizontal pole
        cairo_move_to(cr, base_x, base_y - 150);
        cairo_line_to(cr, base_x + 80, base_y - 150);
        cairo_stroke(cr);
    }
    if (wrong_count >= 4) {
        // Rope
        cairo_move_to(cr, base_x + 80, base_y - 150);
        cairo_line_to(cr, base_x + 80, base_y - 120);
        cairo_stroke(cr);
    }
    if (wrong_count >= 5) {
        // Head
        cairo_arc(cr, base_x + 80, base_y - 100, 20, 0, 2 * G_PI);
        cairo_stroke(cr);
    }
    if (wrong_count >= 6) {
        // Body
        cairo_move_to(cr, base_x + 80, base_y - 80);
        cairo_line_to(cr, base_x + 80, base_y - 30);
        cairo_stroke(cr);

        // Arms
        cairo_move_to(cr, base_x + 80, base_y - 70);
        cairo_line_to(cr, base_x + 60, base_y - 50);
        cairo_stroke(cr);

        cairo_move_to(cr, base_x + 80, base_y - 70);
        cairo_line_to(cr, base_x + 100, base_y - 50);
        cairo_stroke(cr);

        // Legs
        cairo_move_to(cr, base_x + 80, base_y - 30);
        cairo_line_to(cr, base_x + 60, base_y - 10);
        cairo_stroke(cr);

        cairo_move_to(cr, base_x + 80, base_y - 30);
        cairo_line_to(cr, base_x + 100, base_y - 10);
        cairo_stroke(cr);

        // Sad mouth (only on losing game)
        if (wrong_count >= MAX_WRONG) {
            cairo_set_line_width(cr, 2.0);
            cairo_move_to(cr, base_x + 70, base_y - 95);
            cairo_curve_to(cr, base_x + 75, base_y - 105, base_x + 85, base_y - 105, base_x + 90, base_y - 95);
            cairo_stroke(cr);
        }
    }

    return GDK_EVENT_STOP;
}



static void on_letter_clicked(GtkWidget *button, gpointer user_data) {
    char ch = (char)GPOINTER_TO_INT(user_data);
    gboolean found = FALSE;

    /* Check if the guessed letter is in the secret word */
    for (size_t i = 0; i < strlen(secret); ++i) {
        if (secret[i] == ch) {
            found = TRUE;
        }
    }

    if (!found) {
        /* Wrong guess: add to wrong letters and increment wrong_count */
        size_t len = strlen(wrong_letters);
        if (len < sizeof(wrong_letters) - 3) {
            wrong_letters[len] = ch;
            wrong_letters[len + 1] = ' ';
            wrong_letters[len + 2] = '\0';
        }
        wrong_count++;
    } else {
        /* Correct guess: reveal letters in display_word */
        reveal_letters_from_guess(ch);
    }

    /* Disable the clicked button */
    gtk_widget_set_sensitive(button, FALSE);

    /* Update labels */
    update_display_label();

    /* Check for win */
    if (is_word_revealed()) {
        handle_win();
        return;
    }

    /* Check for loss */
    if (wrong_count >= MAX_WRONG) {
        /* Trigger redraw to show final hangman (including sad mouth) */
        gtk_widget_queue_draw(drawing_area);
        handle_loss();
        return;
    }

    /* Restart timer for next guess */
    start_turn_timer();

    /* Trigger redraw to update hangman shape after wrong guess */
    gtk_widget_queue_draw(drawing_area);
}


/* ---------- Reset / New Game ---------- */
static void reset_game(void) {
    stop_turn_timer();

    wrong_count = 0;
    wrong_letters[0] = '\0';

    pick_random_word_for_difficulty();
    build_display_word();
    enable_all_letter_buttons();
    update_display_label();
    gtk_widget_queue_draw(drawing_area);
    start_turn_timer();
}

static void show_rules_dialog_and_start(void) {
    const char *rules =
        "HANGMAN - Rules:\n\n"
        "1) You have 6 wrong guesses allowed.\n"
        "2) Each guess has a 5-second timer � if time runs out it's a wrong guess.\n"
        "3) Choose difficulty from the dropdown (Easy/Medium/Hard).\n"
        "4) Use the letter buttons to guess letters.\n\n"
        "Click Play to start the game.";

    GtkWidget *dialog = gtk_message_dialog_new(GTK_WINDOW(window),
                                               GTK_DIALOG_MODAL,
                                               GTK_MESSAGE_INFO,
                                               GTK_BUTTONS_NONE,
                                               "%s", rules);
    gtk_window_set_title(GTK_WINDOW(dialog), "Rules");
    gtk_dialog_add_buttons(GTK_DIALOG(dialog),
                           "_Play", GTK_RESPONSE_OK,
                           "_Quit", GTK_RESPONSE_CANCEL,
                           NULL);

    gint resp = gtk_dialog_run(GTK_DIALOG(dialog));
    gtk_widget_destroy(dialog);

    if (resp == GTK_RESPONSE_OK) {
        countdown = 5;  // set countdown start value
		g_timeout_add_seconds(1, countdown_tick, NULL);
    } else {
        gtk_main_quit();
    }
}

int main(int argc, char **argv) {
    gtk_init(&argc, &argv);
    srand((unsigned int)time(NULL));

    /* Load resources */
    load_words_from_file(WORDS_FILE);
    load_score();

    window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
    gtk_window_set_default_size(GTK_WINDOW(window), 820, 520);
    gtk_window_set_title(GTK_WINDOW(window), "Hangman (GTK3)");

    g_signal_connect(window, "destroy", G_CALLBACK(gtk_main_quit), NULL);

    ensure_css_provider(); /* set up CSS */
    apply_css_for_mode();

    GtkWidget *vbox = gtk_box_new(GTK_ORIENTATION_VERTICAL, 8);
    gtk_container_set_border_width(GTK_CONTAINER(vbox), 12);
    gtk_container_add(GTK_CONTAINER(window), vbox);

    /* Top bar: Score, Difficulty, Timer, Buttons */
    GtkWidget *top_hbox = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 8);
    gtk_box_pack_start(GTK_BOX(vbox), top_hbox, FALSE, FALSE, 0);

    score_label = gtk_label_new(NULL);
    gtk_widget_set_name(score_label, "score_label");
    update_score_label();
    gtk_box_pack_start(GTK_BOX(top_hbox), score_label, FALSE, FALSE, 6);

    /* Difficulty combo */
    difficulty_combo = gtk_combo_box_text_new();
    gtk_combo_box_text_append_text(GTK_COMBO_BOX_TEXT(difficulty_combo), "Easy");
    gtk_combo_box_text_append_text(GTK_COMBO_BOX_TEXT(difficulty_combo), "Medium");
    gtk_combo_box_text_append_text(GTK_COMBO_BOX_TEXT(difficulty_combo), "Hard");
    gtk_combo_box_set_active(GTK_COMBO_BOX(difficulty_combo), 1); /* default Medium */
    gtk_box_pack_start(GTK_BOX(top_hbox), difficulty_combo, FALSE, FALSE, 6);

    /* Timer label */
    label_timer = gtk_label_new("Time: 5");
    gtk_box_pack_end(GTK_BOX(top_hbox), label_timer, FALSE, FALSE, 6);

    /* Main content: drawing area + right column */
    GtkWidget *hbox = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 10);
    gtk_box_pack_start(GTK_BOX(vbox), hbox, TRUE, TRUE, 6);

    drawing_area = gtk_drawing_area_new();
    gtk_widget_set_size_request(drawing_area, 260, 240);
    g_signal_connect(G_OBJECT(drawing_area), "draw", G_CALLBACK(on_draw), NULL);
    gtk_box_pack_start(GTK_BOX(hbox), drawing_area, FALSE, FALSE, 4);

    /* Right column */
    GtkWidget *right = gtk_box_new(GTK_ORIENTATION_VERTICAL, 8);
    gtk_box_pack_start(GTK_BOX(hbox), right, TRUE, TRUE, 4);

    /* Word label (bigger text) */
    label_word = gtk_label_new("");
    PangoAttrList *attr = pango_attr_list_new();
    PangoAttribute *size_attr = pango_attr_size_new_absolute(28 * PANGO_SCALE);
    pango_attr_list_insert(attr, size_attr);
    gtk_label_set_attributes(GTK_LABEL(label_word), attr);
    pango_attr_list_unref(attr);
    gtk_box_pack_start(GTK_BOX(right), label_word, FALSE, FALSE, 4);

    /* Wrong letters label */
    label_wrong = gtk_label_new("");
    gtk_box_pack_start(GTK_BOX(right), label_wrong, FALSE, FALSE, 4);

    /* Grid of letter buttons */
    btn_grid = gtk_grid_new();
    gtk_grid_set_row_spacing(GTK_GRID(btn_grid), 6);
    gtk_grid_set_column_spacing(GTK_GRID(btn_grid), 6);
    gtk_box_pack_start(GTK_BOX(right), btn_grid, TRUE, TRUE, 4);

    int col = 0, row = 0;
    for (char c = 'A'; c <= 'Z'; ++c) {
        char lbl[2] = { c, '\0' };
        GtkWidget *b = gtk_button_new_with_label(lbl);
        gtk_widget_set_size_request(b, 44, 36);
        gtk_grid_attach(GTK_GRID(btn_grid), b, col, row, 1, 1);
        g_signal_connect(G_OBJECT(b), "clicked", G_CALLBACK(on_letter_clicked), GINT_TO_POINTER((int)c));
        ++col;
        if (col >= 9) { col = 0; row++; }
    }

    /* Bottom controls: New Game, Toggle Dark Mode, Quit */
    GtkWidget *controls = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 8);
    gtk_box_pack_start(GTK_BOX(vbox), controls, FALSE, FALSE, 4);

    GtkWidget *new_btn = gtk_button_new_with_label("New Game");
    g_signal_connect_swapped(new_btn, "clicked", G_CALLBACK(reset_game), NULL);
    gtk_box_pack_start(GTK_BOX(controls), new_btn, FALSE, FALSE, 4);

    GtkWidget *dark_btn = gtk_button_new_with_label("Toggle Dark Mode");
    g_signal_connect(dark_btn, "clicked", G_CALLBACK(toggle_dark_mode), NULL);
    gtk_box_pack_start(GTK_BOX(controls), dark_btn, FALSE, FALSE, 4);

    GtkWidget *quit_btn = gtk_button_new_with_label("Quit");
    g_signal_connect_swapped(quit_btn, "clicked", G_CALLBACK(gtk_main_quit), NULL);
    gtk_box_pack_end(GTK_BOX(controls), quit_btn, FALSE, FALSE, 4);

    /* Show everything */
    gtk_widget_show_all(window);

    /* Show rules dialog first; it will start the first game or quit */
    show_rules_dialog_and_start();

    gtk_main();

    /* Cleanup */
    stop_turn_timer();
    save_score();
    free_words();
    if (css_provider) g_object_unref(css_provider);
    return 0;
}

